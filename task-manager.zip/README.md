# Simple Task Manager

A basic React task manager app that allows you to:

- View a list of tasks
- Add a new task
- Mark a task as completed
- Delete a task

## How to run

1. Install dependencies:

```bash
npm install
```

2. Start the development server:

```bash
npm start
```

3. Open your browser at `http://localhost:3000`

## Features

- Tasks are stored in local component state
- Completed tasks are styled with a line-through
- Simple UI with minimal styling