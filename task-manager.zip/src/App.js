import React, { useState } from 'react';

const initialTasks = [
  { id: 1, title: 'Buy groceries', completed: false },
  { id: 2, title: 'Read a book', completed: true },
];

export default function TaskManager() {
  const [tasks, setTasks] = useState(initialTasks);
  const [newTask, setNewTask] = useState('');

  const addTask = () => {
    if (!newTask.trim()) return; // validation: non-empty
    const task = {
      id: Date.now(),
      title: newTask.trim(),
      completed: false,
    };
    setTasks([task, ...tasks]);
    setNewTask('');
  };

  const toggleCompleted = (id) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  return (
    <div style={{ maxWidth: 400, margin: '2rem auto', fontFamily: 'Arial, sans-serif' }}>
      <h2>Simple Task Manager</h2>

      <div style={{ marginBottom: 16 }}>
        <input
          type="text"
          placeholder="New task"
          value={newTask}
          onChange={e => setNewTask(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && addTask()}
          style={{ padding: 8, width: '70%' }}
        />
        <button onClick={addTask} style={{ padding: '8px 12px', marginLeft: 8 }}>
          Add
        </button>
      </div>

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {tasks.map(task => (
          <li key={task.id} style={{
            display: 'flex',
            alignItems: 'center',
            marginBottom: 8,
            background: '#f9f9f9',
            padding: '8px 12px',
            borderRadius: 4,
          }}>
            <input
              type="checkbox"
              checked={task.completed}
              onChange={() => toggleCompleted(task.id)}
              style={{ marginRight: 12 }}
            />
            <span style={{
              flex: 1,
              textDecoration: task.completed ? 'line-through' : 'none',
              color: task.completed ? '#888' : '#000'
            }}>
              {task.title}
            </span>
            <button onClick={() => deleteTask(task.id)} style={{
              background: 'red',
              border: 'none',
              color: 'white',
              padding: '4px 8px',
              borderRadius: 4,
              cursor: 'pointer',
            }}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}